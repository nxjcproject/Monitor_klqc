﻿(function ($) {
    $.getUrlParam = function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]); return null;
    }
    $.dateFormatter = function (date) {
        if (!date) { return ''; }
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        var d = date.getDate();
        return y + '-' + (m < 10 ? ('0' + m) : m) + '-' + (d < 10 ? ('0' + d) : d);
    }
    $.dateParser = function (s) {
        if (!s) { return null; }
        var ss = s.split('-');
        var y = parseInt(ss[0], 10);
        var m = parseInt(ss[1], 10);
        var d = parseInt(ss[2], 10);
        if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
            return new Date(y, m - 1, d);
        } else {
            return new Date();
        }
    }
    $.jsonDateToDateTime = function (jsonDate) {
        // 转换JSON日期至字符串
        jsonDate = jsonDate.split('(')[1].split(')')[0];
        var rDate = new Date(parseInt(jsonDate));
        return rDate.toLocaleString();
    }
})(jQuery);